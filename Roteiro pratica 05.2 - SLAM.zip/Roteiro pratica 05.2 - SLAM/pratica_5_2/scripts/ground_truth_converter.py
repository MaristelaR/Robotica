#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry


class GroundTruthConverter(Node):

    def __init__(self):
        super().__init__('ground_truth_converter')

        # Armazena a posição e orientação inicial do robô
        self.initial_x = None
        self.initial_y = None
        self.initial_yaw = None

        # Recebe a odometria real do robô
        self.subscription = self.create_subscription(
            Odometry,
            '/ground_truth/odom',
            self.callback,
            10
        )

        # Publica a odometria em relação à posição inicial
        self.publisher = self.create_publisher(
            Odometry,
            '/ground_truth/odom_relative',
            10
        )

        self.get_logger().info('Ground truth converter iniciado.')

    def callback(self, msg):

        # Extrai o yaw a partir da orientação em quaternion
        q = msg.pose.pose.orientation

        yaw = math.atan2(
            2.0 * (q.w * q.z + q.x * q.y),
            1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        )

        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y

        # Define a primeira posição recebida como referência
        if self.initial_x is None:
            self.initial_x = x
            self.initial_y = y
            self.initial_yaw = yaw

        # Calcula o deslocamento em relação à posição inicial
        dx = x - self.initial_x
        dy = y - self.initial_y

        # Converte o deslocamento para o referencial inicial do robô
        x_rel = (
            math.cos(self.initial_yaw) * dx
            + math.sin(self.initial_yaw) * dy
        )

        y_rel = (
            -math.sin(self.initial_yaw) * dx
            + math.cos(self.initial_yaw) * dy
        )

        # Calcula a orientação relativa e normaliza o ângulo
        yaw_rel = yaw - self.initial_yaw
        yaw_rel = math.atan2(math.sin(yaw_rel), math.cos(yaw_rel))

        # Cria a mensagem de odometria relativa
        output = Odometry()
        output.header = msg.header
        output.header.frame_id = 'odom'
        output.child_frame_id = 'chassis'

        output.pose.pose.position.x = x_rel
        output.pose.pose.position.y = y_rel
        output.pose.pose.position.z = 0.0

        # Converte o yaw relativo novamente para quaternion
        output.pose.pose.orientation.z = math.sin(yaw_rel / 2.0)
        output.pose.pose.orientation.w = math.cos(yaw_rel / 2.0)

        # Define pequenas incertezas para posição e orientação
        output.pose.covariance[0] = 0.0001
        output.pose.covariance[7] = 0.0001
        output.pose.covariance[35] = 0.0001

        self.publisher.publish(output)


def main(args=None):
    rclpy.init(args=args)
    node = GroundTruthConverter()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()