#!/usr/bin/env python3

import copy
import math

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu


# Extrai o yaw a partir de um quaternion
def yaw_of(q):
    return math.atan2(
        2 * (q.w * q.z + q.x * q.y),
        1 - 2 * (q.y * q.y + q.z * q.z)
    )


# Converte o yaw para quaternion
def set_yaw(q, yaw):
    q.x = 0.0
    q.y = 0.0
    q.z = math.sin(yaw / 2)
    q.w = math.cos(yaw / 2)


class NoiseInjector(Node):

    def __init__(self):
        super().__init__('noise_injector')

        # Parâmetros de desvio padrão dos ruídos e tópicos
        defaults = {
            'odom_pos_std': 0.05,
            'odom_yaw_std': 0.03,
            'odom_v_std': 0.05,
            'odom_w_std': 0.05,
            'imu_yaw_std': 0.05,
            'imu_w_std': 0.05,
            'odom_input_topic': '/odom',
            'odom_output_topic': '/odom_noisy',
        }

        for name, value in defaults.items():
            self.declare_parameter(name, value)

        input_topic = self.get_parameter(
            'odom_input_topic'
        ).value

        output_topic = self.get_parameter(
            'odom_output_topic'
        ).value

        # Publicadores das mensagens com ruído
        self.odom_pub = self.create_publisher(
            Odometry, output_topic, 10
        )

        self.imu_pub = self.create_publisher(
            Imu, '/imu/data_noisy', 10
        )

        # Assinantes das mensagens originais
        self.odom_sub = self.create_subscription(
            Odometry,
            input_topic,
            self.odom_cb,
            10
        )

        self.imu_sub = self.create_subscription(
            Imu,
            '/imu/data',
            self.imu_cb,
            qos_profile_sensor_data
        )

        self.get_logger().info(
            f'Injetor iniciado: {input_topic} -> {output_topic}'
        )

    # Obtém o valor de um parâmetro
    def p(self, name):
        return self.get_parameter(name).value

    def odom_cb(self, msg):

        # Cria uma cópia para preservar a mensagem original
        odom = copy.deepcopy(msg)

        pos_std = self.p('odom_pos_std')
        yaw_std = self.p('odom_yaw_std')
        vel_std = self.p('odom_v_std')
        ang_std = self.p('odom_w_std')

        # Adiciona ruído gaussiano à posição
        odom.pose.pose.position.x += np.random.normal(0, pos_std)
        odom.pose.pose.position.y += np.random.normal(0, pos_std)

        # Adiciona ruído à orientação
        yaw = yaw_of(msg.pose.pose.orientation)
        yaw += np.random.normal(0, yaw_std)

        set_yaw(odom.pose.pose.orientation, yaw)

        # Adiciona ruído às velocidades linear e angular
        odom.twist.twist.linear.x += np.random.normal(0, vel_std)
        odom.twist.twist.angular.z += np.random.normal(0, ang_std)

        # Atualiza as covariâncias conforme os ruídos aplicados
        odom.pose.covariance[0] = pos_std ** 2
        odom.pose.covariance[7] = pos_std ** 2
        odom.pose.covariance[35] = yaw_std ** 2

        odom.twist.covariance[0] = vel_std ** 2
        odom.twist.covariance[35] = ang_std ** 2

        self.odom_pub.publish(odom)

    def imu_cb(self, msg):

        # Cria uma cópia para preservar a mensagem original
        imu = copy.deepcopy(msg)

        yaw_std = self.p('imu_yaw_std')
        ang_std = self.p('imu_w_std')

        # Adiciona ruído à orientação
        yaw = yaw_of(msg.orientation)
        yaw += np.random.normal(0, yaw_std)

        set_yaw(imu.orientation, yaw)

        # Adiciona ruído à velocidade angular
        imu.angular_velocity.z += np.random.normal(0, ang_std)

        # Atualiza as covariâncias da IMU
        imu.orientation_covariance[8] = yaw_std ** 2
        imu.angular_velocity_covariance[8] = ang_std ** 2

        self.imu_pub.publish(imu)


def main(args=None):

    rclpy.init(args=args)
    node = NoiseInjector()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
