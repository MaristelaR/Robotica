cmake_minimum_required(VERSION 3.8)
project(pratica_5_2)

if(CMAKE_COMPILER_IS_GNUCXX OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

# find dependencies
find_package(ament_cmake REQUIRED)
# uncomment the following section in order to fill in
# further dependencies manually.
# find_package(<dependency> REQUIRED)

if(BUILD_TESTING)
  find_package(ament_lint_auto REQUIRED)
  # the following line skips the linter which checks for copyrights
  # comment the line when a copyright and license is added to all source files
  set(ament_cmake_copyright_FOUND TRUE)
  # the following line skips cpplint (only works in a git repo)
  # comment the line when this package is in a git repo and when
  # a copyright and license is added to all source files
  set(ament_cmake_cpplint_FOUND TRUE)
  ament_lint_auto_find_test_dependencies()
endif()

# Instala os diretórios do projeto
install(
  DIRECTORY launch models config worlds
  DESTINATION share/${PROJECT_NAME}
)

# Instala os programas Python
install(
  PROGRAMS
    scripts/gps_to_xyz.py
    scripts/scan_to_pointcloud.py
    scripts/trajectory_eight.py
    scripts/trajectory_eight_sensors.py
    scripts/noise_injector.py
    scripts/ground_truth_converter.py
  DESTINATION lib/${PROJECT_NAME}
)

ament_package()


