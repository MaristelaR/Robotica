import os

from launch import LaunchDescription
from launch.actions import (
    IncludeLaunchDescription,
    DeclareLaunchArgument,
    OpaqueFunction
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.parameter_descriptions import ParameterValue


def launch_setup(context, *args, **kwargs):

    package_share = get_package_share_directory('pratica_5_2')
    gazebo_ros_dir = get_package_share_directory('gazebo_ros')

    # Configuração do ruído do LiDAR
    lidar_noise_value = LaunchConfiguration('lidar_noise').perform(context)

    robot_urdf_path = os.path.join(
        package_share, 'models', 'my_robot', 'model.urdf'
    )

    with open(robot_urdf_path, 'r', encoding='utf-8') as urdf_file:
        robot_description_content = urdf_file.read()

    robot_description_content = robot_description_content.replace(
        '${LIDAR_NOISE}', lidar_noise_value
    )

    world_path = os.path.join(
        package_share, 'worlds', 'simple_world.world'
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_ros_dir, 'launch', 'gazebo.launch.py')
        ),
        launch_arguments={'world': world_path}.items()
    )

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description_content,
            'use_sim_time': True,
        }],
    )

    spawn_robot = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-topic', 'robot_description',
            '-entity', 'my_robot',
            '-x', '0', '-y', '0', '-z', '0.11',
        ],
        output='screen',
    )

    # Configuração do ruído da odometria
    noise_level = LaunchConfiguration('noise_level')
    k = noise_level

    noise_node = Node(
        package='pratica_5_2',
        executable='noise_injector.py',
        name='noise_node',
        output='screen',
        parameters=[{
            'odom_pos_std': ParameterValue(
                PythonExpression([k, ' * 0.05']), value_type=float
            ),
            'odom_yaw_std': ParameterValue(
                PythonExpression([k, ' * 0.03']), value_type=float
            ),
            'odom_v_std': ParameterValue(
                PythonExpression([k, ' * 0.05']), value_type=float
            ),
            'odom_w_std': ParameterValue(
                PythonExpression([k, ' * 0.05']), value_type=float
            ),
            'imu_yaw_std': 0.05,
            'imu_w_std': 0.05,
            'odom_input_topic': LaunchConfiguration('odom_input_topic'),
            'odom_output_topic': LaunchConfiguration('odom_output_topic'),
        }],
    )

    ground_truth_node = Node(
        package='pratica_5_2',
        executable='ground_truth_converter.py',
        name='ground_truth_converter',
        output='screen',
    )

    ekf_node = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node',
        output='screen',
        parameters=[
            os.path.join(package_share, 'config', 'ekf.yaml'),
            {
                'use_sim_time': True,
                'odom0': LaunchConfiguration('ekf_odom_topic'),
            },
        ],
        remappings=[
            ('odometry/filtered', '/odometry/filtered'),
        ],
    )

    slam_params_file = os.path.join(
        package_share, 'config', 'slam_toolbox.yaml'
    )

    slam_node = Node(
        package='slam_toolbox',
        executable='localization_slam_toolbox_node',
        name='slam_toolbox',
        output='screen',
        parameters=[
            slam_params_file,
            {'use_sim_time': True},
        ],
    )

    return [
        gazebo,
        robot_state_publisher_node,
        spawn_robot,
        noise_node,
        ground_truth_node,
        ekf_node,
        slam_node,
    ]


def generate_launch_description():

    return LaunchDescription([

        DeclareLaunchArgument(
            'lidar_noise',
            default_value='0.01',
            description='Desvio padrão do ruído do LiDAR'
        ),

        DeclareLaunchArgument(
            'noise_level',
            default_value='1.0',
            description='Multiplicador do ruído da odometria'
        ),

        DeclareLaunchArgument(
            'odom_input_topic',
            default_value='/odom',
            description='Tópico de entrada da odometria'
        ),

        DeclareLaunchArgument(
            'odom_output_topic',
            default_value='/odom_noisy',
            description='Tópico de saída da odometria com ruído'
        ),

        DeclareLaunchArgument(
            'ekf_odom_topic',
            default_value='/ground_truth/odom_relative',
            description='Tópico de odometria utilizado pelo EKF'
        ),

        OpaqueFunction(function=launch_setup),

    ])
